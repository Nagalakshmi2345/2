import os
import pandas as pandas
import matplotlib.pyplot as pyplot
market_caps={
    'appl':2300,
    'mfst':2100,
    'googl':1600,
    'AMZN':1700,
    'TSLA':900,
    'NVDA':500,
    'META':700,
    'BRK_B':600,
    'JNJ':400,
    'V':500
}
top_10_companies={
    'appl':'apple inc',
    'mfst':'microsoft copration',
    'googl':'alphabet inc',
    'AMZN':'amzon .com ,inc',
    'TSLA':'telsa,inc',
    'NVDA':'berkshire hathaway inc.',
    'META':'nvidia corporation',
    'BRK_B':'meta platform,inc',
    'JNJ':'johnson and johnson',
    'v':'visa Inc',
}
current_directory=os.path.dirname(os.path.abspath(__file__))
csv_file_path=os.path.join(current_directory,'top_10_stocks_sample_2013_2023.csv')
df=pandas.read_csv(csv_file_path)
df['Date']=pandas.to_datetime(df['Date'])
df['year']=df['Date'].dt.year
stock_columns=['appl_close',
    'mfst_close',
    'googl_close',
    'AMZN_close',
    'TSLA_close',
    'NVDA_close',
    'META_close',
    'BRK_close',
    'JNJ_close',
    'v_close']
average_prices=df.groupby('year')['stock_columns'].mean().reset_index()
pyplot.figure(figsize=(20,10))
bar_width=0.1
years=average_prices['year']
positions=[years+i*bar_width for i in range(len(stock_columns))]
for i,column in enumerate(stock_columns):
    pyplot.bar(positions[i],average_prices[column],width=bar_width,label=column.split('_')[0])
pyplot.xlabel('year')
pyplot.ylabel('average closing price')
pyplot.title('Average closing price of top 10 stocks(2013-2023)')
pyplot.xticks(years+bar_width*4.5,years)
pyplot.legend()
pyplot.tight_layout()
pyplot.show()